#ifndef __MOTOR_H
#define __MOTOR_H
extern void Motor_Init(void);
//步进电机正转函数（反转参考51版本）
extern void Motorcw(float n);
extern void Motorpw(float n);


#endif
