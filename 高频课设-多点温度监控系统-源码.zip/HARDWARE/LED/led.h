#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define LEDG PCout(13)	// LED�ӿ�	
#define LEDR PAout(4)	// LED�ӿ�	

#define LED_OFF1		1
#define LED_ON1		0

void LED_Init(void);//��ʼ��
			    
#endif
