char KAIQI[]="开启";
char GUANBI[]="关闭";
char BANKAI[]="半开";

